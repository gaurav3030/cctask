<?php
$host = "localhost";
$username = "root";
$pass = "";
$dbname = "tasksystem";

$conn = mysqli_connect($host,$username,$pass,$dbname);
?>